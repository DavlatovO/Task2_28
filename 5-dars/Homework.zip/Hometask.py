# from mydecorators import check_admin
from mydecorators import check_time
import time

#1
# @check_age
# def car_owner(name, car):
#     return f"{name} becomes the owner of {car}"

# result = car_owner('Islombek', 'Hyundai Elantra')
# print(result)

#2
# @check_age
# def car_owner(name, car):
#     return f"{name} becomes the owner of {car}"

# result = car_owner('Islombek', 'Hyundai Elantra')
# print(result)

#3
# @check_admin
# def car_owner(data1, data2):
#     return f"{data1} worked {data2}"

# result = car_owner('Function', 'Successfully')
# print(result)

#4
# @check_time
# def car_owner(data1, data2):
#     time.sleep(3)
#     return f"{data1} worked {data2}"

# result = car_owner('Function', 'Successfully')
# print(result)